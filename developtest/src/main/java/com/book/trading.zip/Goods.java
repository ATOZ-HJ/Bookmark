package com.book.trading;

public enum Goods {
	BREAD,
	COAL,
	FISH,
	HELMET,
	IRON,
	PAPER,
	SHIELD,
	SWORD,
	WOOD,
	WOOL;
}
